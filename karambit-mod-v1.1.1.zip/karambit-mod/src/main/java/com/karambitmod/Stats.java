package com.karambitmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** Proste statystyki liczone po stronie klienta: FPS (z liczby klatek HUD) i prędkość gracza. */
public final class Stats {
    public static int fps;
    public static double speed;          // bloki / sekundę (poziomo)

    private static int frames;
    private static long lastFpsMs = System.currentTimeMillis();
    private static double px, pz;
    private static boolean has;

    private Stats() {}

    /** Wywoływane raz na klatkę (z callbacku HUD). */
    public static void frame() {
        frames++;
        long now = System.currentTimeMillis();
        if (now - lastFpsMs >= 1000) {
            fps = frames;
            frames = 0;
            lastFpsMs = now;
        }
    }

    /** Wywoływane co tick. */
    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) { has = false; speed = 0; return; }
        if (has) {
            double dx = p.getX() - px, dz = p.getZ() - pz;
            double inst = Math.sqrt(dx * dx + dz * dz) * 20.0;
            if (inst > 100) inst = 0;                         // teleport
            speed += (inst - speed) * 0.3;
        }
        px = p.getX();
        pz = p.getZ();
        has = true;
    }
}

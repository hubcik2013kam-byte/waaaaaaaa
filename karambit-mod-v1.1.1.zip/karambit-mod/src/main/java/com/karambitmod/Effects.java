package com.karambitmod;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Efekty świata (czysto klienckie, zwykłe cząsteczki vanilla):
 * ślad kroków, iskry przy trafieniu przeciwnika i latające świetliki.
 */
public final class Effects {
    private static final class Bit {
        double x, y, z, vx, vy, vz, grav, drag;
        int life, max, color;
        float size, phase;
        boolean fly;
    }

    private static final List<Bit> BITS = new ArrayList<>();
    private static final Random R = new Random();
    private static final int MAX_BITS = 320;
    private static long age;

    private Effects() {}

    public static void init() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient()) onHit(entity);
            return ActionResult.PASS;
        });
    }

    public static void tick(MinecraftClient mc) {
        Cfg c = Cfg.I;
        ClientWorld w = mc.world;
        ClientPlayerEntity p = mc.player;
        if (w == null || p == null || !c.modEnabled || !c.effectsEnabled) { BITS.clear(); return; }
        if (mc.isPaused()) return;
        age++;
        if (c.fxTrail) trail(w, p, c);
        if (c.fxFireflies) spawnFlies(w, p, c);
        step(w, c);
    }

    // ------------------------------------------------------------ ślad kroków

    private static void trail(ClientWorld w, ClientPlayerEntity p, Cfg c) {
        if (!p.isOnGround() || Stats.speed < 1.0) return;
        if (c.fxTrailSprint && !p.isSprinting()) return;
        for (int i = 0; i < 2; i++) {
            float t = (float) ((Math.sin(age * 0.08 + i) + 1.0) / 2.0);
            int col = Cfg.lerp(c.fxColorA, c.fxColorB, t);
            w.addParticleClient(effect(c, col, c.fxSize),
                    p.getX() + (R.nextDouble() - 0.5) * 0.4, p.getY() + 0.06, p.getZ() + (R.nextDouble() - 0.5) * 0.4,
                    0, 0.01, 0);
        }
    }

    // ------------------------------------------------------------ trafienie

    private static void onHit(Entity e) {
        Cfg c = Cfg.I;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!c.modEnabled || !c.effectsEnabled || !c.fxHit || mc.world == null || !(e instanceof LivingEntity)) return;
        double cx = e.getX(), cy = e.getY() + e.getHeight() * 0.55, cz = e.getZ();
        for (int i = 0; i < c.fxHitCount && BITS.size() < MAX_BITS; i++) {
            double th = R.nextDouble() * Math.PI * 2;
            double ph = Math.acos(2 * R.nextDouble() - 1);
            double sp = 0.12 + R.nextDouble() * 0.16;
            Bit b = new Bit();
            b.x = cx; b.y = cy; b.z = cz;
            b.vx = Math.sin(ph) * Math.cos(th) * sp;
            b.vy = Math.cos(ph) * sp + 0.05;
            b.vz = Math.sin(ph) * Math.sin(th) * sp;
            b.grav = 0.012;
            b.drag = 0.86;
            b.max = b.life = 8 + R.nextInt(8);
            b.color = Cfg.lerp(c.fxColorA, c.fxColorB, R.nextFloat());
            b.size = c.fxSize;
            BITS.add(b);
        }
    }

    // ------------------------------------------------------------ świetliki

    private static void spawnFlies(ClientWorld w, ClientPlayerEntity p, Cfg c) {
        int flies = 0;
        for (Bit b : BITS) if (b.fly) flies++;
        if (flies >= c.fxFlyCount || BITS.size() >= MAX_BITS || R.nextInt(3) != 0) return;

        double ang = R.nextDouble() * Math.PI * 2;
        double r = 2 + R.nextDouble() * 9;
        double x = p.getX() + Math.cos(ang) * r;
        double z = p.getZ() + Math.sin(ang) * r;
        double y = p.getY() + R.nextDouble() * 3.0 - 0.5;
        BlockPos bp = new BlockPos(MathHelper.floor(x), MathHelper.floor(y), MathHelper.floor(z));
        if (!w.getBlockState(bp).isAir()) return;
        if (c.fxDarkOnly && w.getLightLevel(bp) > 7) return;

        Bit b = new Bit();
        b.x = x; b.y = y; b.z = z;
        b.drag = 0.95;
        b.max = b.life = 80 + R.nextInt(80);
        b.color = Cfg.lerp(c.fxColorA, c.fxColorB, R.nextFloat());
        b.size = c.fxSize;
        b.phase = R.nextFloat() * 6.28f;
        b.fly = true;
        BITS.add(b);
    }

    // ------------------------------------------------------------ symulacja

    private static void step(ClientWorld w, Cfg c) {
        Iterator<Bit> it = BITS.iterator();
        while (it.hasNext()) {
            Bit b = it.next();
            if (b.fly) {
                b.vx += (R.nextDouble() - 0.5) * 0.012;
                b.vz += (R.nextDouble() - 0.5) * 0.012;
                b.vy += (R.nextDouble() - 0.5) * 0.008 + Math.sin(age * 0.1 + b.phase) * 0.0012;
            }
            b.vy -= b.grav;
            b.x += b.vx; b.y += b.vy; b.z += b.vz;
            b.vx *= b.drag; b.vy *= b.drag; b.vz *= b.drag;
            if (--b.life <= 0) { it.remove(); continue; }

            float frac = (float) b.life / b.max;
            float sz = b.fly
                    ? b.size * (0.4f + 0.6f * (float) Math.sin(Math.PI * (1.0 - frac)))
                    : b.size * (0.5f + 0.5f * frac);
            if (!b.fly || (age & 1) == 0) {
                w.addParticleClient(effect(c, b.color, Math.max(0.15f, sz)), b.x, b.y, b.z, 0, 0, 0);
            }
        }
    }

    private static ParticleEffect effect(Cfg c, int color, float size) {
        return switch (c.fxType) {
            case DUST -> new DustParticleEffect(color, size);
            case END_ROD -> ParticleTypes.END_ROD;
            case FLAME -> ParticleTypes.FLAME;
            case SOUL_FIRE -> ParticleTypes.SOUL_FIRE_FLAME;
            case ELECTRIC_SPARK -> ParticleTypes.ELECTRIC_SPARK;
            case HAPPY_VILLAGER -> ParticleTypes.HAPPY_VILLAGER;
        };
    }
}
